<template>
  <div class="min-h-screen bg-gray-50">
    <!-- Admin Navigation -->
    <nav class="bg-white shadow-md">
      <div class="container mx-auto px-4 py-4 flex justify-between items-center">
        <h1 class="text-2xl font-bold text-blue-900">إدارة المشاريع | Projects Management</h1>
        <div class="flex items-center gap-4">
          <router-link to="/admin/dashboard" class="text-gray-600 hover:text-blue-600">
            لوحة التحكم | Dashboard
          </router-link>
          <router-link to="/" class="text-gray-600 hover:text-blue-600">
            الصفحة الرئيسية | Home
          </router-link>
        </div>
      </div>
    </nav>
    
    <div class="container mx-auto px-4 py-8">
      <div class="mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 class="text-2xl font-bold text-gray-900">المشاريع</h2>
          <p class="text-gray-600 mt-1">إدارة مشاريع الشركة وأعمالها المنجزة</p>
        </div>
        <router-link
          to="/admin/projects/new"
          class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors inline-flex items-center gap-2 whitespace-nowrap"
        >
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
          </svg>
          إضافة مشروع جديد
        </router-link>
      </div>

      <!-- Projects Table -->
      <div class="bg-white rounded-xl shadow-sm overflow-hidden">
        <div v-if="loading" class="p-12 text-center">
          <div class="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>

        <div v-else-if="projects.length === 0" class="p-12 text-center text-gray-500">
          <svg class="w-16 h-16 mx-auto mb-1 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
          </svg>
          <p class="text-lg font-medium">لا توجد مشاريع</p>
          <p class="mt-2">ابدأ بإضافة مشروع جديد</p>
        </div>

        <table v-else class="w-full">
          <thead class="bg-gray-50 border-b">
            <tr>
              <th class="px-6 py-4 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">المشروع</th>
              <th class="px-6 py-4 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">النوع</th>
              <th class="px-6 py-4 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">مميز</th>
              <th class="px-6 py-4 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">الترتيب</th>
              <th class="px-6 py-4 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">الإجراءات</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-200">
            <tr v-for="project in paginatedProjects" :key="project.id" class="hover:bg-gray-50">
              <td class="px-6 py-4">
                <div class="flex items-center gap-4">
                  <div v-if="project.media_type === 'image' && project.media_url" class="w-16 h-16 rounded-lg overflow-hidden bg-gray-200 flex-shrink-0">
                    <img :src="project.media_url" :alt="project.title" class="w-full h-full object-cover" />
                  </div>
                  <div v-else class="w-16 h-16 rounded-lg bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center flex-shrink-0">
                    <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                    </svg>
                  </div>
                  <div>
                    <div class="font-semibold text-gray-900">{{ project.title }}</div>
                    <div class="text-sm text-gray-600">{{ project.title_ar }}</div>
                  </div>
                </div>
              </td>
              <td class="px-6 py-4">
                <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium"
                  :class="{
                    'bg-blue-100 text-blue-800': project.media_type === 'image',
                    'bg-purple-100 text-purple-800': project.media_type === 'video',
                    'bg-gray-100 text-gray-800': project.media_type === 'text'
                  }">
                  {{ project.media_type === 'image' ? 'صورة' : project.media_type === 'video' ? 'فيديو' : 'نص' }}
                </span>
              </td>
              <td class="px-6 py-4 text-center">
                <span v-if="project.is_featured" class="text-2xl">⭐</span>
                <span v-else class="text-gray-400">-</span>
              </td>
              <td class="px-6 py-4 text-center">
                <span class="font-medium text-gray-900">{{ project.order }}</span>
              </td>
              <td class="px-6 py-4">
                <div class="flex items-center justify-center gap-2">
                  <router-link
                    :to="`/admin/projects/${project.id}`"
                    class="text-blue-600 hover:text-blue-800 p-2"
                    title="تعديل"
                  >
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                    </svg>
                  </router-link>
                  <button
                    @click="confirmDelete(project)"
                    class="text-red-600 hover:text-red-800 p-2"
                    title="حذف"
                  >
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                    </svg>
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>

        <!-- Pagination -->
        <div v-if="projects.length > 0" class="px-6 py-4 bg-gray-50 border-t flex items-center justify-between">
          <div class="text-sm text-gray-700">
            عرض {{ ((currentPage - 1) * perPage) + 1 }} إلى {{ Math.min(currentPage * perPage, projects.length) }} من {{ projects.length }} مشروع
          </div>
          <div class="flex gap-2">
            <button
              @click="currentPage--"
              :disabled="currentPage === 1"
              class="px-4 py-2 border rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100"
            >
              السابق
            </button>
            <button
              v-for="page in totalPages"
              :key="page"
              @click="currentPage = page"
              class="px-4 py-2 border rounded-lg"
              :class="currentPage === page ? 'bg-blue-600 text-white border-blue-600' : 'hover:bg-gray-100'"
            >
              {{ page }}
            </button>
            <button
              @click="currentPage++"
              :disabled="currentPage === totalPages"
              class="px-4 py-2 border rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100"
            >
              التالي
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'

interface Project {
  id: number
  title: string
  title_ar: string
  description: string
  description_ar: string
  media_type: 'image' | 'video' | 'text'
  media_url: string | null
  order: number
  is_featured: boolean
}

const projects = ref<Project[]>([])
const loading = ref(true)
const currentPage = ref(1)
const perPage = 10

const totalPages = computed(() => Math.ceil(projects.value.length / perPage))
const paginatedProjects = computed(() => {
  const start = (currentPage.value - 1) * perPage
  const end = start + perPage
  return projects.value.slice(start, end)
})

const fetchProjects = async () => {
  try {
    const response = await axios.get('/api/projects')
    projects.value = response.data
  } catch (error) {
    console.error('Error fetching projects:', error)
  } finally {
    loading.value = false
  }
}

const confirmDelete = async (project: Project) => {
  if (confirm(`هل أنت متأكد من حذف المشروع "${project.title_ar}"؟`)) {
    try {
      await axios.delete(`/api/projects/${project.id}`)
      projects.value = projects.value.filter(p => p.id !== project.id)
      alert('تم حذف المشروع بنجاح')
    } catch (error) {
      console.error('Error deleting project:', error)
      alert('حدث خطأ أثناء حذف المشروع')
    }
  }
}

onMounted(() => {
  fetchProjects()
})
</script>
