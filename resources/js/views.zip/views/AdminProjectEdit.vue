<template>
  <div class="min-h-screen bg-gray-50">
    <!-- Admin Navigation -->
    <nav class="bg-white shadow-md">
      <div class="container mx-auto px-4 py-4 flex justify-between items-center">
        <h1 class="text-2xl font-bold text-blue-900">
          {{ isNew ? 'إضافة مشروع جديد' : 'تعديل المشروع' }}
        </h1>
        <div class="flex items-center gap-4">
          <router-link to="/admin/projects" class="text-gray-600 hover:text-blue-600">
            المشاريع | Projects
          </router-link>
          <router-link to="/admin/dashboard" class="text-gray-600 hover:text-blue-600">
            لوحة التحكم | Dashboard
          </router-link>
        </div>
      </div>
    </nav>
    
    <div class="container mx-auto px-4 py-8">
      <div class="mb-8">
        <p class="text-gray-600">
          {{ isNew ? 'أضف مشروع جديد إلى صفحة المشاريع' : 'تعديل بيانات المشروع' }}
        </p>
      </div>

      <div class="bg-white rounded-xl shadow-sm p-8">
        <form @submit.prevent="handleSubmit" class="space-y-6">
          <!-- Title -->
          <div class="grid md:grid-cols-2 gap-6">
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                العنوان بالعربي *
              </label>
              <input
                v-model="form.title_ar"
                type="text"
                required
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="اسم المشروع بالعربي"
              />
            </div>
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                Title (English) *
              </label>
              <input
                v-model="form.title"
                type="text"
                required
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Project name in English"
              />
            </div>
          </div>

          <!-- Description -->
          <div class="grid md:grid-cols-2 gap-6">
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                الوصف بالعربي *
              </label>
              <textarea
                v-model="form.description_ar"
                required
                rows="6"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="وصف المشروع بالتفصيل"
              ></textarea>
            </div>
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                Description (English) *
              </label>
              <textarea
                v-model="form.description"
                required
                rows="6"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Project description in detail"
              ></textarea>
            </div>
          </div>

          <!-- Media Type -->
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">
              نوع الوسائط *
            </label>
            <div class="flex gap-4">
              <label class="flex items-center gap-2 cursor-pointer">
                <input
                  v-model="form.media_type"
                  type="radio"
                  value="image"
                  class="w-4 h-4 text-blue-600"
                />
                <span>صورة | Image</span>
              </label>
              <label class="flex items-center gap-2 cursor-pointer">
                <input
                  v-model="form.media_type"
                  type="radio"
                  value="video"
                  class="w-4 h-4 text-blue-600"
                />
                <span>فيديو | Video</span>
              </label>
              <label class="flex items-center gap-2 cursor-pointer">
                <input
                  v-model="form.media_type"
                  type="radio"
                  value="text"
                  class="w-4 h-4 text-blue-600"
                />
                <span>نص فقط | Text Only</span>
              </label>
            </div>
          </div>

          <!-- Media Upload/URL -->
          <div v-if="form.media_type !== 'text'">
            <label class="block text-sm font-medium text-gray-700 mb-1">
              {{ form.media_type === 'image' ? 'رفع صورة' : 'رفع فيديو' }}
            </label>
            
            <!-- File Upload -->
            <div class="mb-1">
              <input
                type="file"
                @change="handleFileChange"
                :accept="form.media_type === 'image' ? 'image/*' : 'video/*'"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <!-- URL Input -->
            <div>
              <label class="block text-sm text-gray-600 mb-1">أو أدخل رابط URL</label>
              <input
                v-model="form.media_url"
                type="text"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="https://..."
              />
            </div>

            <!-- Preview -->
            <div v-if="previewUrl || form.media_url" class="mt-4">
              <label class="block text-sm font-medium text-gray-700 mb-1">معاينة</label>
              <div class="border rounded-lg p-4 bg-gray-50">
                <img
                  v-if="form.media_type === 'image'"
                  :src="previewUrl || form.media_url"
                  alt="Preview"
                  class="max-h-64 rounded-lg"
                />
                <video
                  v-else-if="form.media_type === 'video'"
                  :src="previewUrl || form.media_url"
                  controls
                  class="max-h-64 rounded-lg"
                ></video>
              </div>
            </div>
          </div>

          <!-- Order and Featured -->
          <div class="grid md:grid-cols-2 gap-6">
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                ترتيب العرض
              </label>
              <input
                v-model.number="form.order"
                type="number"
                min="0"
                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="0"
              />
              <p class="text-xs text-gray-500 mt-1">الأرقام الأصغر تظهر أولاً</p>
            </div>
            <div class="flex items-center">
              <label class="flex items-center gap-3 cursor-pointer">
                <input
                  v-model="form.is_featured"
                  type="checkbox"
                  class="w-5 h-5 text-blue-600 rounded"
                />
                <div>
                  <div class="font-medium text-gray-900">مشروع مميز ⭐</div>
                  <div class="text-sm text-gray-600">سيظهر بتمييز خاص في الصفحة</div>
                </div>
              </label>
            </div>
          </div>

          <!-- Actions -->
          <div class="flex items-center justify-end gap-4 pt-6 border-t">
            <router-link
              to="/admin/projects"
              class="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              إلغاء
            </router-link>
            <button
              type="submit"
              :disabled="submitting"
              class="bg-blue-600 hover:bg-blue-700 text-white px-8 py-2 rounded-lg font-medium transition-colors disabled:opacity-50"
            >
              {{ submitting ? 'جاري الحفظ...' : (isNew ? 'إضافة المشروع' : 'حفظ التعديلات') }}
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import axios from 'axios'

const route = useRoute()
const router = useRouter()

const isNew = computed(() => !route.params.id)

const form = ref({
  title: '',
  title_ar: '',
  description: '',
  description_ar: '',
  media_type: 'image' as 'image' | 'video' | 'text',
  media_url: '',
  order: 0,
  is_featured: false,
})

const mediaFile = ref<File | null>(null)
const previewUrl = ref('')
const submitting = ref(false)

const handleFileChange = (e: Event) => {
  const target = e.target as HTMLInputElement
  if (target.files && target.files[0]) {
    mediaFile.value = target.files[0]
    previewUrl.value = URL.createObjectURL(target.files[0])
  }
}

const fetchData = async () => {
  if (isNew.value) return

  try {
    const response = await axios.get(`/api/projects/${route.params.id}`)
    const project = response.data
    form.value = {
      title: project.title,
      title_ar: project.title_ar,
      description: project.description,
      description_ar: project.description_ar,
      media_type: project.media_type,
      media_url: project.media_url || '',
      order: project.order,
      is_featured: project.is_featured,
    }
  } catch (error) {
    console.error('Error fetching project:', error)
    alert('حدث خطأ في تحميل بيانات المشروع')
  }
}

const handleSubmit = async () => {
  submitting.value = true

  try {
    const formData = new FormData()
    formData.append('title', form.value.title)
    formData.append('title_ar', form.value.title_ar)
    formData.append('description', form.value.description)
    formData.append('description_ar', form.value.description_ar)
    formData.append('media_type', form.value.media_type)
    if (form.value.media_url) {
      formData.append('media_url', form.value.media_url)
    }
    if (mediaFile.value) {
      formData.append('media_file', mediaFile.value)
    }
    formData.append('order', form.value.order.toString())
    formData.append('is_featured', form.value.is_featured ? '1' : '0')

    if (isNew.value) {
      await axios.post('/api/projects', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
      alert('تم إضافة المشروع بنجاح')
    } else {
      // Use POST for update (route accepts both POST and PUT)
      await axios.post(`/api/projects/${route.params.id}`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
      alert('تم تعديل المشروع بنجاح')
    }

    router.push('/admin/projects')
  } catch (error: any) {
    console.error('Error saving project:', error)
    alert(error.response?.data?.message || 'حدث خطأ أثناء حفظ المشروع')
  } finally {
    submitting.value = false
  }
}

onMounted(() => {
  fetchData()
})
</script>
