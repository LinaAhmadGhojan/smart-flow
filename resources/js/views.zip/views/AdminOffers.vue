<template>
  <div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b border-gray-200 p-6">
      <div class="max-w-7xl mx-auto">
        <div class="flex items-center justify-between">
          <div>
            <h1 class="text-3xl font-bold text-gray-900">إدارة العروض | Manage Offers</h1>
            <p class="text-gray-600 mt-1">إضافة وتعديل وحذف العروض الخاصة</p>
          </div>
          <button
            @click="showForm = true"
            class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium flex items-center gap-2 transition-colors"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
            </svg>
            إضافة عرض جديد | Add Offer
          </button>
        </div>
      </div>
    </div>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto p-6">
      <!-- Loading State -->
      <div v-if="loading" class="flex items-center justify-center py-12">
        <div class="text-center">
          <div class="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          <p class="mt-4 text-gray-600">جاري التحميل...</p>
        </div>
      </div>

      <!-- Offers Table -->
      <div v-else class="bg-white rounded-lg shadow-md overflow-hidden">
        <div v-if="offers.length > 0" class="overflow-x-auto">
          <table class="w-full">
            <thead class="bg-gray-100 border-b border-gray-200">
              <tr>
                <th class="px-6 py-3 text-right text-sm font-semibold text-gray-900">المنتج</th>
                <th class="px-6 py-3 text-right text-sm font-semibold text-gray-900">نسبة الخصم</th>
                <th class="px-6 py-3 text-right text-sm font-semibold text-gray-900">تاريخ البداية</th>
                <th class="px-6 py-3 text-right text-sm font-semibold text-gray-900">تاريخ النهاية</th>
                <th class="px-6 py-3 text-right text-sm font-semibold text-gray-900">الحالة</th>
                <th class="px-6 py-3 text-right text-sm font-semibold text-gray-900">الإجراءات</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
              <tr v-for="offer in offers" :key="offer.id" class="hover:bg-gray-50 transition-colors">
                <td class="px-6 py-4">
                  <div class="flex items-center gap-3">
                    <img
                      :src="offer.product.image || '/placeholder-product.jpg'"
                      :alt="offer.product.name"
                      class="w-12 h-12 object-cover rounded"
                    />
                    <div>
                      <p class="font-medium text-gray-900">{{ offer.product.name }}</p>
                      <p class="text-sm text-gray-600">{{ offer.product.name_ar }}</p>
                    </div>
                  </div>
                </td>
                <td class="px-6 py-4">
                  <div class="font-bold text-red-600">{{ offer.discount_percentage }}%</div>
                </td>
                <td class="px-6 py-4 text-sm text-gray-600">
                  {{ offer.start_date ? new Date(offer.start_date).toLocaleDateString('ar-AE') : 'بدون تاريخ' }}
                </td>
                <td class="px-6 py-4 text-sm text-gray-600">
                  {{ offer.end_date ? new Date(offer.end_date).toLocaleDateString('ar-AE') : 'بدون تاريخ' }}
                </td>
                <td class="px-6 py-4">
                  <span
                    :class="[
                      'inline-flex items-center px-3 py-1 rounded-full text-xs font-medium',
                      offer.is_active 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-gray-100 text-gray-800'
                    ]"
                  >
                    {{ offer.is_active ? 'مفعل | Active' : 'معطل | Inactive' }}
                  </span>
                </td>
                <td class="px-6 py-4">
                  <div class="flex items-center gap-2">
                    <button
                      @click="editOffer(offer)"
                      class="text-blue-600 hover:text-blue-800 font-medium"
                    >
                      تعديل | Edit
                    </button>
                    <button
                      @click="deleteOffer(offer.id)"
                      class="text-red-600 hover:text-red-800 font-medium"
                    >
                      حذف | Delete
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Empty State -->
        <div v-else class="text-center py-12">
          <svg class="w-16 h-16 mx-auto text-gray-400 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4"/>
          </svg>
          <h3 class="text-xl font-semibold text-gray-900 mb-1">لا توجد عروض</h3>
          <p class="text-gray-600 mb-6">ابدأ بإضافة عرض جديد لمنتجاتك</p>
          <button
            @click="showForm = true"
            class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
          >
            إضافة عرض جديد
          </button>
        </div>
      </div>
    </div>

    <!-- Form Modal -->
    <div v-if="showForm" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div class="bg-white rounded-lg max-w-2xl w-full max-h-96 overflow-y-auto">
        <!-- Form Header -->
        <div class="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between">
          <h2 class="text-2xl font-bold text-gray-900">
            {{ editingOffer ? 'تعديل عرض | Edit Offer' : 'إضافة عرض جديد | Add New Offer' }}
          </h2>
          <button
            @click="closeForm"
            class="text-gray-500 hover:text-gray-700"
          >
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>
          </button>
        </div>

        <!-- Form Body -->
        <form @submit.prevent="saveOffer" class="p-6 space-y-4">
          <!-- Product Select -->
          <div>
            <label class="block text-sm font-medium text-gray-900 mb-1">
              المنتج | Product <span class="text-red-500">*</span>
            </label>
            <select
              v-model="formData.product_id"
              required
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
            >
              <option value="">-- اختر منتج --</option>
              <option v-for="product in products" :key="product.id" :value="product.id">
                {{ product.name }} - {{ product.name_ar }}
              </option>
            </select>
          </div>

          <!-- Discount Percentage -->
          <div>
            <label class="block text-sm font-medium text-gray-900 mb-1">
              نسبة الخصم | Discount Percentage <span class="text-red-500">*</span>
            </label>
            <input
              v-model.number="formData.discount_percentage"
              type="number"
              min="0"
              max="100"
              required
              placeholder="مثلاً: 20"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
            />
          </div>

          <!-- Discount Price (Optional) -->
          <div>
            <label class="block text-sm font-medium text-gray-900 mb-1">
              سعر الخصم (اختياري) | Discount Price
            </label>
            <input
              v-model.number="formData.discount_price"
              type="number"
              min="0"
              placeholder="اتركها فارغة لحساب تلقائي"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
            />
          </div>

          <!-- Start Date -->
          <div>
            <label class="block text-sm font-medium text-gray-900 mb-1">
              تاريخ البداية | Start Date
            </label>
            <input
              v-model="formData.start_date"
              type="datetime-local"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
            />
          </div>

          <!-- End Date -->
          <div>
            <label class="block text-sm font-medium text-gray-900 mb-1">
              تاريخ النهاية | End Date
            </label>
            <input
              v-model="formData.end_date"
              type="datetime-local"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
            />
          </div>

          <!-- Description -->
          <div>
            <label class="block text-sm font-medium text-gray-900 mb-1">
              وصف العرض | Offer Description
            </label>
            <textarea
              v-model="formData.offer_description"
              rows="3"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              placeholder="وصف العرض بالإنجليزية"
            ></textarea>
          </div>

          <!-- Description AR -->
          <div>
            <label class="block text-sm font-medium text-gray-900 mb-1">
              وصف العرض | Offer Description AR
            </label>
            <textarea
              v-model="formData.offer_description_ar"
              rows="3"
              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              placeholder="وصف العرض بالعربية"
            ></textarea>
          </div>

          <!-- Is Active -->
          <div class="flex items-center gap-3">
            <input
              v-model="formData.is_active"
              type="checkbox"
              id="is_active"
              class="w-4 h-4 text-blue-600 rounded focus:ring-2"
            />
            <label for="is_active" class="text-sm font-medium text-gray-900">
              مفعل | Active
            </label>
          </div>

          <!-- Buttons -->
          <div class="flex gap-3 pt-4 border-t border-gray-200">
            <button
              type="submit"
              :disabled="saving"
              class="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-6 py-3 rounded-lg font-medium transition-colors"
            >
              {{ saving ? 'جاري الحفظ...' : 'حفظ | Save' }}
            </button>
            <button
              type="button"
              @click="closeForm"
              class="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-900 px-6 py-3 rounded-lg font-medium transition-colors"
            >
              إلغاء | Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'

interface Product {
  id: number
  name: string
  name_ar: string
  image: string
}

interface Offer {
  id: number
  product_id: number
  discount_percentage: number
  discount_price: number | null
  offer_description: string
  offer_description_ar: string
  start_date: string | null
  end_date: string | null
  is_active: boolean
  product: Product
}

interface FormData {
  product_id: number | null
  discount_percentage: number | null
  discount_price: number | null
  offer_description: string
  offer_description_ar: string
  start_date: string
  end_date: string
  is_active: boolean
}

const offers = ref<Offer[]>([])
const products = ref<Product[]>([])
const loading = ref(true)
const saving = ref(false)
const showForm = ref(false)
const editingOffer = ref<Offer | null>(null)

const formData = ref<FormData>({
  product_id: null,
  discount_percentage: null,
  discount_price: null,
  offer_description: '',
  offer_description_ar: '',
  start_date: '',
  end_date: '',
  is_active: true,
})

const resetForm = () => {
  formData.value = {
    product_id: null,
    discount_percentage: null,
    discount_price: null,
    offer_description: '',
    offer_description_ar: '',
    start_date: '',
    end_date: '',
    is_active: true,
  }
  editingOffer.value = null
}

const closeForm = () => {
  showForm.value = false
  resetForm()
}

const editOffer = (offer: Offer) => {
  editingOffer.value = offer
  formData.value = {
    product_id: offer.product_id,
    discount_percentage: offer.discount_percentage,
    discount_price: offer.discount_price,
    offer_description: offer.offer_description,
    offer_description_ar: offer.offer_description_ar,
    start_date: offer.start_date ? new Date(offer.start_date).toISOString().slice(0, 16) : '',
    end_date: offer.end_date ? new Date(offer.end_date).toISOString().slice(0, 16) : '',
    is_active: offer.is_active,
  }
  showForm.value = true
}

const saveOffer = async () => {
  if (!formData.value.product_id || !formData.value.discount_percentage) {
    alert('الرجاء ملء جميع الحقول المطلوبة')
    return
  }

  saving.value = true
  try {
    const url = editingOffer.value 
      ? `/api/offers/${editingOffer.value.id}`
      : '/api/offers'
    
    const method = editingOffer.value ? 'PUT' : 'POST'
    
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    }
    
    // Get CSRF token
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content')
    if (csrfToken) {
      headers['X-CSRF-TOKEN'] = csrfToken
    }
    
    const token = sessionStorage.getItem('authToken')
    if (token) {
      headers['Authorization'] = `Bearer ${token}`
    }

    const response = await fetch(url, {
      method,
      headers,
      credentials: 'same-origin',
      body: JSON.stringify(formData.value)
    })

    if (response.ok) {
      closeForm()
      await loadOffers()
      alert(editingOffer.value ? 'تم تحديث العرض بنجاح' : 'تم إضافة العرض بنجاح')
    } else {
      const error = await response.text()
      alert('حدث خطأ: ' + error)
    }
  } catch (error) {
    console.error('Error:', error)
    alert('حدث خطأ في الاتصال')
  } finally {
    saving.value = false
  }
}

const deleteOffer = async (id: number) => {
  if (!confirm('هل أنت متأكد من حذف هذا العرض؟')) {
    return
  }

  try {
    const headers: HeadersInit = {
      'Accept': 'application/json',
    }
    
    // Get CSRF token
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content')
    if (csrfToken) {
      headers['X-CSRF-TOKEN'] = csrfToken
    }
    
    const token = sessionStorage.getItem('authToken')
    if (token) {
      headers['Authorization'] = `Bearer ${token}`
    }

    const response = await fetch(`/api/offers/${id}`, {
      method: 'DELETE',
      headers,
      credentials: 'same-origin'
    })

    if (response.ok) {
      await loadOffers()
      alert('تم حذف العرض بنجاح')
    } else {
      alert('فشل حذف العرض')
    }
  } catch (error) {
    console.error('Error:', error)
    alert('حدث خطأ في الاتصال')
  }
}

const loadOffers = async () => {
  try {
    const response = await fetch('/api/offers')
    const data = await response.json()
    offers.value = data.offers || []
  } catch (error) {
    console.error('Error loading offers:', error)
  }
}

const loadProducts = async () => {
  try {
    const response = await fetch('/api/products')
    const data = await response.json()
    products.value = data.products || []
  } catch (error) {
    console.error('Error loading products:', error)
  }
}

onMounted(async () => {
  loading.value = true
  await Promise.all([loadOffers(), loadProducts()])
  loading.value = false
})
</script>

