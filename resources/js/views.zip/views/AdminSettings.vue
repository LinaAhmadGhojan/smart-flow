<template>
  <div class="min-h-screen bg-gray-50">
    <div class="container mx-auto px-4 py-8">
      <!-- Header -->
      <div class="mb-8">
        <div class="flex items-center justify-between">
          <div>
            <h1 class="text-3xl font-bold text-gray-900">إعدادات الشركة | Company Settings</h1>
            <p class="text-gray-600 mt-2">تعديل معلومات التواصل وبيانات الشركة</p>
          </div>
          <router-link
            to="/admin/dashboard"
            class="bg-gray-600 hover:bg-gray-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
          >
            العودة للوحة التحكم
          </router-link>
        </div>
      </div>

      <!-- Success Message -->
      <div v-if="successMessage" class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg relative">
        <span class="block sm:inline">{{ successMessage }}</span>
        <button @click="successMessage = ''" class="absolute top-0 bottom-0 left-0 px-4">
          <span class="text-2xl">&times;</span>
        </button>
      </div>

      <!-- Error Message -->
      <div v-if="errorMessage" class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative">
        <span class="block sm:inline">{{ errorMessage }}</span>
        <button @click="errorMessage = ''" class="absolute top-0 bottom-0 left-0 px-4">
          <span class="text-2xl">&times;</span>
        </button>
      </div>

      <!-- Settings Form -->
      <div class="bg-white rounded-xl shadow-lg p-8">
        <form @submit.prevent="saveSettings">
          <!-- Company Info Section -->
          <div class="mb-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6 pb-3 border-b">
              معلومات الشركة | Company Information
            </h2>
            
            <div class="grid md:grid-cols-2 gap-6">
              <!-- Company Name English -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  اسم الشركة (English)
                </label>
                <input
                  v-model="settings.companyName"
                  type="text"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <!-- Company Name Arabic -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  اسم الشركة (عربي)
                </label>
                <input
                  v-model="settings.companyNameAr"
                  type="text"
                  dir="rtl"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <!-- Tagline English -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  الشعار (English)
                </label>
                <input
                  v-model="settings.tagline"
                  type="text"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <!-- Tagline Arabic -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  الشعار (عربي)
                </label>
                <input
                  v-model="settings.taglineAr"
                  type="text"
                  dir="rtl"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <!-- Description English -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  الوصف (English)
                </label>
                <textarea
                  v-model="settings.description"
                  rows="3"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                ></textarea>
              </div>

              <!-- Description Arabic -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  الوصف (عربي)
                </label>
                <textarea
                  v-model="settings.descriptionAr"
                  rows="3"
                  dir="rtl"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                ></textarea>
              </div>
            </div>
          </div>

          <!-- Contact Info Section -->
          <div class="mb-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6 pb-3 border-b">
              معلومات التواصل | Contact Information
            </h2>
            
            <div class="grid md:grid-cols-2 gap-6">
              <!-- Email -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  البريد الإلكتروني | Email
                </label>
                <input
                  v-model="settings.contact.email"
                  type="email"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <!-- Phone -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  رقم الهاتف | Phone
                </label>
                <input
                  v-model="settings.contact.phone"
                  type="text"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="+971 50 123 4567"
                  required
                />
              </div>

              <!-- WhatsApp -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  واتساب | WhatsApp
                  <span class="text-sm text-gray-500">(بدون +)</span>
                </label>
                <input
                  v-model="settings.contact.whatsapp"
                  type="text"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="971501234567"
                  required
                />
              </div>

              <!-- Address English -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  العنوان (English)
                </label>
                <input
                  v-model="settings.contact.address.en"
                  type="text"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <!-- Address Arabic -->
              <div class="md:col-span-2">
                <label class="block text-gray-700 font-medium mb-1">
                  العنوان (عربي)
                </label>
                <input
                  v-model="settings.contact.address.ar"
                  type="text"
                  dir="rtl"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
            </div>
          </div>

          <!-- Working Hours Section -->
          <div class="mb-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6 pb-3 border-b">
              ساعات العمل | Working Hours
            </h2>
            
            <div class="grid md:grid-cols-2 gap-6">
              <!-- Working Hours English -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  ساعات العمل (English)
                </label>
                <input
                  v-model="settings.workingHours.en"
                  type="text"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Sunday - Thursday: 9:00 AM - 6:00 PM"
                  required
                />
              </div>

              <!-- Working Hours Arabic -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  ساعات العمل (عربي)
                </label>
                <input
                  v-model="settings.workingHours.ar"
                  type="text"
                  dir="rtl"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="الأحد - الخميس: 9:00 صباحاً - 6:00 مساءً"
                  required
                />
              </div>
            </div>
          </div>

          <!-- Social Media Section -->
          <div class="mb-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6 pb-3 border-b">
              وسائل التواصل الاجتماعي | Social Media
            </h2>
            
            <div class="grid md:grid-cols-2 gap-6">
              <!-- Facebook -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  Facebook
                </label>
                <input
                  v-model="settings.social.facebook"
                  type="url"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="https://facebook.com/yourpage"
                />
              </div>

              <!-- Instagram -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  Instagram
                </label>
                <input
                  v-model="settings.social.instagram"
                  type="url"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="https://instagram.com/yourpage"
                />
              </div>

              <!-- Twitter -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  Twitter
                </label>
                <input
                  v-model="settings.social.twitter"
                  type="url"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="https://twitter.com/yourpage"
                />
              </div>

              <!-- LinkedIn -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  LinkedIn
                </label>
                <input
                  v-model="settings.social.linkedin"
                  type="url"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="https://linkedin.com/company/yourpage"
                />
              </div>
            </div>
          </div>

          <!-- About Section -->
          <div class="mb-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6 pb-3 border-b">
              عن الشركة | About Us
            </h2>
            
            <div class="grid md:grid-cols-1 gap-6">
              <!-- About English -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  نبذة عن الشركة (English)
                </label>
                <textarea
                  v-model="settings.about.en"
                  rows="4"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                ></textarea>
              </div>

              <!-- About Arabic -->
              <div>
                <label class="block text-gray-700 font-medium mb-1">
                  نبذة عن الشركة (عربي)
                </label>
                <textarea
                  v-model="settings.about.ar"
                  rows="4"
                  dir="rtl"
                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                ></textarea>
              </div>
            </div>
          </div>

          <!-- Submit Button -->
          <div class="flex items-center justify-end gap-4 pt-6 border-t">
            <router-link
              to="/admin/dashboard"
              class="px-6 py-3 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition-colors"
            >
              إلغاء
            </router-link>
            <button
              type="submit"
              :disabled="saving"
              class="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {{ saving ? 'جاري الحفظ...' : 'حفظ التعديلات | Save Changes' }}
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

interface Settings {
  companyName: string
  companyNameAr: string
  tagline: string
  taglineAr: string
  description: string
  descriptionAr: string
  footerDescAr: string
  contact: {
    email: string
    phone: string
    whatsapp: string
    address: {
      en: string
      ar: string
    }
  }
  workingHours: {
    en: string
    ar: string
  }
  social: {
    facebook: string
    twitter: string
    instagram: string
    linkedin: string
  }
  about: {
    en: string
    ar: string
  }
  seo: {
    keywords: string
    location: {
      city: string
      cityAr: string
      country: string
      countryAr: string
      countryCode: string
      region: string
    }
  }
}

const settings = ref<Settings>({
  companyName: '',
  companyNameAr: '',
  tagline: '',
  taglineAr: '',
  description: '',
  descriptionAr: '',
  footerDescAr: '',
  contact: {
    email: '',
    phone: '',
    whatsapp: '',
    address: {
      en: '',
      ar: ''
    }
  },
  workingHours: {
    en: '',
    ar: ''
  },
  social: {
    facebook: '',
    twitter: '',
    instagram: '',
    linkedin: ''
  },
  about: {
    en: '',
    ar: ''
  },
  seo: {
    keywords: '',
    location: {
      city: 'Dubai',
      cityAr: 'دبي',
      country: 'United Arab Emirates',
      countryAr: 'الإمارات العربية المتحدة',
      countryCode: 'AE',
      region: 'Middle East'
    }
  }
})

const saving = ref(false)
const successMessage = ref('')
const errorMessage = ref('')

const loadSettings = async () => {
  try {
    const response = await fetch('/company-info.json')
    if (!response.ok) {
      throw new Error('Failed to load settings')
    }
    const data = await response.json()
    
    // دمج البيانات مع القيم الافتراضية للتأكد من وجود جميع الحقول
    settings.value = {
      companyName: data.companyName || '',
      companyNameAr: data.companyNameAr || '',
      tagline: data.tagline || '',
      taglineAr: data.taglineAr || '',
      description: data.description || '',
      descriptionAr: data.descriptionAr || '',
      footerDescAr: data.footerDescAr || '',
      contact: {
        email: data.contact?.email || '',
        phone: data.contact?.phone || '',
        whatsapp: data.contact?.whatsapp || '',
        address: {
          en: data.contact?.address?.en || '',
          ar: data.contact?.address?.ar || ''
        }
      },
      workingHours: {
        en: data.workingHours?.en || '',
        ar: data.workingHours?.ar || ''
      },
      social: {
        facebook: data.social?.facebook || '',
        twitter: data.social?.twitter || '',
        instagram: data.social?.instagram || '',
        linkedin: data.social?.linkedin || ''
      },
      about: {
        en: data.about?.en || '',
        ar: data.about?.ar || ''
      },
      seo: {
        keywords: data.seo?.keywords || '',
        location: {
          city: data.seo?.location?.city || 'Dubai',
          cityAr: data.seo?.location?.cityAr || 'دبي',
          country: data.seo?.location?.country || 'United Arab Emirates',
          countryAr: data.seo?.location?.countryAr || 'الإمارات العربية المتحدة',
          countryCode: data.seo?.location?.countryCode || 'AE',
          region: data.seo?.location?.region || 'Middle East'
        }
      }
    }
  } catch (error) {
    console.error('Error loading settings:', error)
    errorMessage.value = 'فشل تحميل الإعدادات - استخدام القيم الافتراضية'
  }
}

const saveSettings = async () => {
  saving.value = true
  successMessage.value = ''
  errorMessage.value = ''

  try {
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content')
    
    const response = await fetch('/api/settings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': csrfToken || '',
        'Accept': 'application/json'
      },
      credentials: 'same-origin',
      body: JSON.stringify(settings.value)
    })

    const data = await response.json()

    if (!response.ok) {
      // عرض رسالة الخطأ من السيرفر
      const errorMsg = data.error || data.message || 'فشل في حفظ الإعدادات'
      throw new Error(errorMsg)
    }

    successMessage.value = '✅ تم حفظ الإعدادات بنجاح!'
    
    // Scroll to top to show success message
    window.scrollTo({ top: 0, behavior: 'smooth' })
    
    // Reload settings to confirm
    await loadSettings()
    
  } catch (error: any) {
    console.error('Error saving settings:', error)
    errorMessage.value = `❌ ${error.message || 'حدث خطأ أثناء حفظ الإعدادات'}`
  } finally {
    saving.value = false
  }
}

onMounted(() => {
  loadSettings()
})
</script>

<style scoped>
input:focus,
textarea:focus {
  outline: none;
}
</style>
