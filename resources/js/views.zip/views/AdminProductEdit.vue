<template>
  <div class="min-h-screen bg-gray-50">
    <nav class="bg-white shadow-md">
      <div class="container mx-auto px-4 py-4 flex justify-between items-center">
        <h1 class="text-2xl font-bold text-blue-900">
          {{ isNew ? 'Add Product | إضافة منتج' : 'Edit Product | تعديل منتج' }}
        </h1>
        <RouterLink to="/admin/products" class="text-gray-600 hover:text-blue-600">
          Back | العودة
        </RouterLink>
      </div>
    </nav>
    
    <div class="container mx-auto px-4 py-8 max-w-2xl">
      <div v-if="error && !isNew" class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-1">
        {{ error }}
      </div>

      <form @submit.prevent="handleSubmit" class="bg-white rounded-lg shadow p-6 space-y-6">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Name (English)</label>
          <input
            v-model="form.name"
            type="text"
            required
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">الاسم (عربي)</label>
          <input
            v-model="form.name_ar"
            type="text"
            required
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Category | الفئة</label>
          <select
            v-model="form.category_id"
            required
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">Select Category</option>
            <option v-for="cat in categories" :key="cat.id" :value="cat.id">
              {{ cat.name }} | {{ cat.name_ar }}
            </option>
          </select>
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Description (English)</label>
          <textarea
            v-model="form.description"
            rows="3"
            required
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          ></textarea>
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">الوصف (عربي)</label>
          <textarea
            v-model="form.description_ar"
            rows="3"
            required
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          ></textarea>
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Price (AED)</label>
          <input
            v-model.number="form.price"
            type="number"
            step="0.01"
            required
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div class="flex items-center">
          <input
            v-model="form.in_stock"
            type="checkbox"
            id="in_stock"
            class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
          />
          <label for="in_stock" class="ml-2 block text-sm text-gray-700">
            In Stock | متوفر في المخزون
          </label>
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">WhatsApp Message | رسالة واتساب</label>
          <textarea
            v-model="form.whatsapp_message"
            rows="3"
            placeholder="Custom message for WhatsApp..."
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          ></textarea>
          <p class="text-sm text-gray-500 mt-1">Optional custom message when sharing via WhatsApp</p>
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Product Image | صورة المنتج</label>
          
          <!-- Image Preview -->
          <div v-if="imagePreview" class="mb-1">
            <img :src="imagePreview" alt="Preview" class="h-32 w-32 object-cover rounded-lg border-2 border-gray-300" />
          </div>

          <!-- File Upload -->
          <input
            type="file"
            accept="image/*"
            @change="handleImageUpload"
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <p class="text-sm text-gray-500 mt-1">Upload product image (JPG, PNG, WebP)</p>
        </div>

        <!-- Dynamic Features -->
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Features | الميزات</label>
          <div class="space-y-2">
            <div v-for="(feature, index) in form.features" :key="index" class="flex gap-2">
              <input
                v-model="form.features[index]"
                type="text"
                placeholder="Enter feature"
                class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <button
                type="button"
                @click="removeFeature(index)"
                class="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors"
              >
                Remove
              </button>
            </div>
          </div>
          <button
            type="button"
            @click="addFeature"
            class="mt-2 px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors"
          >
            + Add Feature
          </button>
        </div>

        <div class="flex gap-4">
          <button
            type="submit"
            :disabled="loading"
            class="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-medium py-3 rounded-lg transition-colors"
          >
            {{ loading ? 'Saving...' : (isNew ? 'Create | إنشاء' : 'Update | تحديث') }}
          </button>
          <RouterLink
            to="/admin/products"
            class="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium py-3 rounded-lg transition-colors text-center leading-[3rem]"
          >
            Cancel | إلغاء
          </RouterLink>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useRoute, useRouter, RouterLink } from 'vue-router'
import api from '@/lib/api'

const route = useRoute()
const router = useRouter()

const isNew = computed(() => !route.params.id )
const loading = ref(false)
const error = ref('')
const categories = ref<any[]>([])
const imagePreview = ref<string | null>(null)
const imageFile = ref<File | null>(null)

const form = ref({
  name: '',
  name_ar: '',
  description: '',
  description_ar: '',
  price: 0,
  image: '',
  category_id: '',
  features: [] as string[],
  in_stock: true,
  whatsapp_message: ''
})

const handleImageUpload = (event: Event) => {
  const target = event.target as HTMLInputElement
  const file = target.files?.[0]
  
  if (file) {
    imageFile.value = file
    const reader = new FileReader()
    reader.onload = (e) => {
      imagePreview.value = e.target?.result as string
    }
    reader.readAsDataURL(file)
  }
}

const addFeature = () => {
  form.value.features.push('')
}

const removeFeature = (index: number) => {
  form.value.features.splice(index, 1)
}

const fetchData = async () => {
  try {
    const categoriesRes = await api.get('/categories')
    categories.value = categoriesRes.data

    if (!isNew.value) {
      const productRes = await api.get(`/products/${route.params.id}`)
      const product = productRes.data
      form.value = {
        name: product.name,
        name_ar: product.name_ar,
        description: product.description,
        description_ar: product.description_ar || product.description_ar,
        price: product.price,
        image: product.image || '',
        category_id: product.category_id || product.categoryId,
        features: product.features || [],
        in_stock: product.in_stock ?? true,
        whatsapp_message: product.whatsapp_message || ''
      }
      
      // Set image preview if exists
      if (product.image) {
        imagePreview.value = product.image
      }
    }
  } catch (err: any) {
    if (!isNew.value) {
      error.value = err.response?.data?.error || 'Failed to load data'
    }
  }
}

const handleSubmit = async () => {
  loading.value = true
  error.value = ''

  try {
    const formData = new FormData()
    formData.append('name', form.value.name)
    formData.append('name_ar', form.value.name_ar)
    formData.append('description', form.value.description)
    formData.append('description_ar', form.value.description_ar)
    formData.append('price', form.value.price.toString())
    formData.append('category_id', form.value.category_id)
    formData.append('in_stock', form.value.in_stock ? '1' : '0')
    formData.append('whatsapp_message', form.value.whatsapp_message)
    
    // Add features as JSON
    formData.append('features', JSON.stringify(form.value.features))
    
    // Add image if uploaded
    if (imageFile.value) {
      formData.append('image', imageFile.value)
    }

    if (isNew.value) {
      await api.post('/products', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
    } else {
      await api.post(`/products/${route.params.id}?_method=PUT`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
    }
    router.push('/admin/products')
  } catch (err: any) {
    error.value = err.response?.data?.error || 'Failed to save product'
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  fetchData()
})
</script>
