<template>
  <div class="min-h-screen bg-gray-50">
    <nav class="bg-white shadow-md">
      <div class="container mx-auto px-4 py-4 flex justify-between items-center">
        <h1 class="text-2xl font-bold text-blue-900">
          {{ isNew ? 'Add Category | إضافة فئة' : 'Edit Category | تعديل فئة' }}
        </h1>
        <RouterLink to="/admin/categories" class="text-gray-600 hover:text-blue-600">
          Back | العودة
        </RouterLink>
      </div>
    </nav>
    
    <div class="container mx-auto px-4 py-8 max-w-2xl">
      <div v-if="error" class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-1">
        {{ error }}
      </div>

      <form @submit.prevent="handleSubmit" class="bg-white rounded-lg shadow p-6 space-y-6">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Name (English)</label>
          <input
            v-model="form.name"
            type="text"
            required
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">الاسم (عربي)</label>
          <input
            v-model="form.name_ar"
            type="text"
            required
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Description | الوصف</label>
          <textarea
            v-model="form.description"
            rows="3"
            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          ></textarea>
        </div>

        <div class="flex gap-4">
          <button
            type="submit"
            :disabled="loading"
            class="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-medium py-3 rounded-lg transition-colors"
          >
            {{ loading ? 'Saving...' : (isNew ? 'Create | إنشاء' : 'Update | تحديث') }}
          </button>
          <RouterLink
            to="/admin/categories"
            class="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium py-3 rounded-lg transition-colors text-center leading-[3rem]"
          >
            Cancel | إلغاء
          </RouterLink>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useRoute, useRouter, RouterLink } from 'vue-router'
import api from '@/lib/api'

const route = useRoute()
const router = useRouter()

const isNew = computed(() => ! route.params.id)
const loading = ref(false)
const error = ref('')

const form = ref({
  name: '',
  name_ar: '',
  description: ''
})

const fetchCategory = async () => {
  if (isNew.value) return

  try {
    const response = await api.get(`/categories/${route.params.id}`)
    form.value = {
      name: response.data.name,
      name_ar: response.data.name_ar,
      description: response.data.description || ''
    }
  } catch (err: any) {
    error.value = err.response?.data?.error || 'Failed to load category'
  }
}

const handleSubmit = async () => {
  loading.value = true
  error.value = ''

  try {
    if (isNew.value) {
      await api.post('/categories', form.value)
    } else {
      await api.put(`/categories/${route.params.id}`, form.value)
    }
    router.push('/admin/categories')
  } catch (err: any) {
    error.value = err.response?.data?.error || 'Failed to save category'
  } finally {
    loading.value = false
  }
}

onMounted(() => {
    console.log('isNew:', isNew.value);
    console.log(route)
  if (!isNew.value) {
    fetchCategory()
  }
})
</script>
