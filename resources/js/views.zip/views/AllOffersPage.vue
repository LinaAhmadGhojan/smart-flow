<template>
  <div class="min-h-screen bg-gray-50">
    <Header />
    
    <div class="pt-24 pb-16">
      <div class="container mx-auto px-4">
        <!-- Page Header -->
        <div class="mb-12">
          <router-link 
            to="/" 
            class="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700 mb-6"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
            </svg>
            العودة للرئيسية | Back to Home
          </router-link>

          <div class="text-center">
            <h1 class="text-4xl md:text-5xl font-bold text-blue-900 mb-1">
              عروضنا الخاصة | Special Offers
            </h1>
            <p class="text-xl text-gray-600">
              احصل على أفضل الحلول الذكية بأسعار مخفضة - دبي، الإمارات
            </p>
          </div>
        </div>

        <!-- Loading State -->
        <div v-if="loading" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div v-for="i in 6" :key="i" class="animate-pulse bg-white rounded-2xl p-6 h-96"></div>
        </div>

        <!-- Offers Grid -->
        <div v-else-if="offers.length > 0" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div
            v-for="offer in offers"
            :key="offer.id"
            class="bg-white rounded-2xl overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border-2 border-blue-200"
          >
            <!-- Image Section -->
            <div class="relative h-56 overflow-hidden">
              <img
                :src="offer.image || '/placeholder-product.jpg'"
                :alt="offer.name"
                class="w-full h-full object-cover"
              />
              <!-- Discount Badge -->
              <div v-if="offer.discount_percentage" class="absolute top-4 left-4 bg-red-600 text-white px-4 py-2 rounded-full font-bold text-lg">
                -{{ offer.discount_percentage }}%
              </div>
              <!-- Status Badge -->
              <div
                :class="[
                  'absolute top-4 right-4 px-3 py-1 rounded-md text-sm font-medium text-white',
                  offer.in_stock ? 'bg-green-600' : 'bg-red-600'
                ]"
              >
                {{ offer.in_stock ? 'متوفر | In Stock' : 'غير متوفر | Out of Stock' }}
              </div>
            </div>

            <!-- Content Section -->
            <div class="p-4">
              <!-- Title -->
              <h3 class="text-lg font-bold text-gray-900 mb-1">
                {{ offer.name }}
              </h3>
              <h4 class="text-sm text-gray-600 mb-1 font-arabic">
                {{ offer.name_ar }}
              </h4>

              <!-- Price Section -->
              <div class="mb-1">
                <div class="flex items-baseline gap-3">
                  <div class="text-2xl font-bold" style="color: #203c85;">
                    {{ formatPrice(offer.discounted_price) }} AED
                  </div>
                  <div v-if="offer.original_price" class="text-lg text-gray-500 line-through">
                    {{ formatPrice(offer.original_price) }} AED
                  </div>
                </div>
              </div>

              <!-- Description -->
              <p v-if="offer.description" class="text-gray-600 text-sm mb-1 line-clamp-2">
                {{ offer.description }}
              </p>

              <!-- Features -->
              <div v-if="offer.features && offer.features.length > 0" class="mb-1 space-y-1">
                <div
                  v-for="(feature, idx) in offer.features.slice(0, 3)"
                  :key="idx"
                  class="flex items-start gap-2 text-gray-700 text-xs"
                >
                  <svg class="w-4 h-4 mt-0.5 flex-shrink-0" style="color: #203c85;" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                  </svg>
                  <span>{{ feature }}</span>
                </div>
              </div>

              <!-- View Details Button -->
              <router-link
                :to="{ name: 'product-details', params: { id: offer.product_id } }"
                class="block w-full bg-blue-600 hover:bg-blue-700 text-white text-center px-4 py-2 rounded-lg font-medium transition-colors mb-1 text-sm"
              >
                تفاصيل | Details
              </router-link>

              <!-- WhatsApp Button -->
              <a
                :href="getWhatsAppLink(offer)"
                target="_blank"
                rel="noopener noreferrer"
                class="flex w-full text-white text-center px-4 py-2 rounded-lg font-medium transition-colors items-center justify-center gap-2"
                style="background-color: #203c85;"
                @mouseover="$event.target.style.backgroundColor='#152a5c'"
                @mouseout="$event.target.style.backgroundColor='#203c85'"
              >
                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
                اطلب عبر واتساب
              </a>
            </div>
          </div>
        </div>

        <!-- No Offers -->
        <div v-else class="text-center py-12">
          <svg class="w-16 h-16 mx-auto text-gray-400 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
          </svg>
          <h3 class="text-2xl font-bold text-gray-900 mb-1">لا توجد عروض حالياً</h3>
          <p class="text-gray-600 mb-6">تحقق مرة أخرى قريباً للحصول على أفضل العروض</p>
          <router-link
            to="/"
            class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
          >
            العودة للرئيسية
          </router-link>
        </div>
      </div>
    </div>

    <Footer />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import Header from '@/components/Header.vue'
import Footer from '@/components/Footer.vue'

interface Offer {
  id: number
  product_id: number
  name: string
  name_ar: string
  brand: string
  image: string
  in_stock: boolean
  features: string[]
  description?: string
  original_price: number
  discounted_price: number
  discount_percentage: number
  whatsapp_message: string
}

interface CompanyInfo {
  contact: {
    whatsapp: string
  }
}

const formatPrice = (price: string | number): string => {
  const numPrice = typeof price === 'string' ? parseFloat(price) : price
  return numPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}

const offers = ref<Offer[]>([])
const companyInfo = ref<CompanyInfo | null>(null)
const loading = ref(true)

const whatsappNumber = computed(() => {
  return companyInfo.value?.contact.whatsapp || '971562566232'
})

const getWhatsAppLink = (offer: Offer) => {
  const message = offer.whatsapp_message || 
    `مرحباً، أرغب في الاستفسار عن العرض: ${offer.name_ar} (${offer.name}) - السعر: ${formatPrice(offer.discounted_price)} AED`
  return `https://wa.me/${whatsappNumber.value}?text=${encodeURIComponent(message)}`
}

onMounted(async () => {
  try {
    const [offersRes, companyRes] = await Promise.all([
      fetch('/api/offers'),
      fetch('/company-info.json')
    ])

    const offersData = await offersRes.json()
    // Filter only active offers
    const allOffers = offersData.offers || []
    offers.value = allOffers.filter((offer: any) => offer.is_active)

    companyInfo.value = await companyRes.json()

    loading.value = false
  } catch (error) {
    console.error('Error loading offers:', error)
    loading.value = false
  }
})
</script>

<style scoped>
.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>
