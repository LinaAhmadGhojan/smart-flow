<template>
  <div class="min-h-screen bg-gray-50">
    <Header />
    <Hero />
    <Offers />
    <Products />
    <OurProjects />
    <About />
    <Contact />
    <Footer />
  </div>
</template>

<script setup lang="ts">
import Header from '@/components/Header.vue'
import Hero from '@/components/Hero.vue'
import Offers from '@/components/Offers.vue'
import Products from '@/components/Products.vue'
import OurProjects from '@/components/OurProjects.vue'
import About from '@/components/About.vue'
import Contact from '@/components/Contact.vue'
import Footer from '@/components/Footer.vue'
</script>
