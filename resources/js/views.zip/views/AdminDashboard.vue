<template>
  <div class="min-h-screen bg-gray-50">
    <nav class="bg-white shadow-md">
      <div class="container mx-auto px-4 py-4 flex justify-between items-center">
        <h1 class="text-2xl font-bold text-blue-900">لوحة التحكم | Dashboard</h1>
        <div class="flex items-center gap-4">
          <RouterLink to="/" class="text-gray-600 hover:text-blue-600">
            الصفحة الرئيسية | Home
          </RouterLink>
          <button
            @click="handleLogout"
            class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors"
          >
            تسجيل الخروج | Logout
          </button>
        </div>
      </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
      <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        <RouterLink
          to="/admin/products"
          class="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow"
        >
          <div class="flex items-center gap-4">
            <div class="bg-blue-100 p-4 rounded-lg">
              <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
              </svg>
            </div>
            <div>
              <h3 class="text-xl font-bold text-gray-900">المنتجات</h3>
              <p class="text-gray-600">Products</p>
            </div>
          </div>
          <p class="mt-4 text-gray-600">إدارة المنتجات والأسعار</p>
        </RouterLink>

        <RouterLink
          to="/admin/offers"
          class="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow"
        >
          <div class="flex items-center gap-4">
            <div class="bg-red-100 p-4 rounded-lg">
              <svg class="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
              </svg>
            </div>
            <div>
              <h3 class="text-xl font-bold text-gray-900">العروض</h3>
              <p class="text-gray-600">Offers</p>
            </div>
          </div>
          <p class="mt-4 text-gray-600">إدارة العروض والخصومات</p>
        </RouterLink>

        <RouterLink
          to="/admin/categories"
          class="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow"
        >
          <div class="flex items-center gap-4">
            <div class="bg-green-100 p-4 rounded-lg">
              <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/>
              </svg>
            </div>
            <div>
              <h3 class="text-xl font-bold text-gray-900">الفئات</h3>
              <p class="text-gray-600">Categories</p>
            </div>
          </div>
          <p class="mt-4 text-gray-600">إدارة فئات المنتجات</p>
        </RouterLink>

        <RouterLink
          to="/admin/projects"
          class="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow"
        >
          <div class="flex items-center gap-4">
            <div class="bg-orange-100 p-4 rounded-lg">
              <svg class="w-8 h-8 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
              </svg>
            </div>
            <div>
              <h3 class="text-xl font-bold text-gray-900">المشاريع</h3>
              <p class="text-gray-600">Projects</p>
            </div>
          </div>
          <p class="mt-4 text-gray-600">إدارة مشاريع الشركة</p>
        </RouterLink>

        <RouterLink
          to="/admin/settings"
          class="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow"
        >
          <div class="flex items-center gap-4">
            <div class="bg-purple-100 p-4 rounded-lg">
              <svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
              </svg>
            </div>
            <div>
              <h3 class="text-xl font-bold text-gray-900">الإعدادات</h3>
              <p class="text-gray-600">Settings</p>
            </div>
          </div>
          <p class="mt-4 text-gray-600">معلومات التواصل والشركة</p>
        </RouterLink>

        <div class="bg-white rounded-xl shadow-lg p-8">
          <div class="flex items-center gap-4">
            <div class="bg-indigo-100 p-4 rounded-lg">
              <svg class="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
              </svg>
            </div>
            <div>
              <h3 class="text-xl font-bold text-gray-900">الإحصائيات</h3>
              <p class="text-gray-600">Statistics</p>
            </div>
          </div>
          <p class="mt-4 text-gray-600">قريباً | Coming Soon</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRouter, RouterLink } from 'vue-router'

const router = useRouter()

const handleLogout = () => {
  sessionStorage.removeItem('adminLoggedIn')
  sessionStorage.removeItem('authToken')
  router.push('/admin')
}
</script>
